﻿namespace Tv_Rv.Config.Web.Models
{
    public class NavModel
    {
        public string ItemName { get; set; }
        public string ControllerName { get; set; }
        public string ActionName { get; set; }
    }
}