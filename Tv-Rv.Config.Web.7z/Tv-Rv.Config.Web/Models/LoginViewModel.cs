﻿using System.ComponentModel.DataAnnotations;

namespace Tv_Rv.Config.Web.Models
{
    public class LoginViewModel
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}